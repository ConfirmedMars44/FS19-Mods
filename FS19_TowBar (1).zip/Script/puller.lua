--
-- FS19 - Tow Bar
-- @author:    	Peppe978, TyKonKet, kenny456 - FS19 conversion (kenny456@seznam.cz)
-- @history:	v1.0 - 2019-01-02 - converted to FS19
--
Puller = {};
source(g_currentModDirectory .. "Script/pullerEvents.lua");

function Puller.prerequisitesPresent(specializations)
	return true
end

function Puller.initSpecialization()
end

function Puller.registerOverwrittenFunctions(vehicleType)
end

function Puller.registerFunctions(vehicleType)
end

function Puller.registerEvents(vehicleType)
end

function Puller:registerActionEventsPlayer()
end

function Puller:registerActionEventsMenu()
end
function Puller:onRegisterActionEvents(isSelected, isOnActiveVehicle)
	if isOnActiveVehicle then
		if self.Puller == nil then 
			self.Puller = {}
		else	
			self:clearActionEventsTable( self.Puller )
		end 
		for _,actionName in pairs({ "PULLER_ATTACH_VEHICLE" }) do
			local _, eventName = self:addActionEvent(self.Puller, InputAction[actionName], self, Puller.actionCallback, true, true, false, true, nil);
			--local __, eventName = InputBinding.registerActionEvent(g_inputBinding, actionName, self, AutoLoadWood2.actionCallback ,false ,true ,false ,true)
			if isSelected then
				g_inputBinding.events[eventName].displayPriority = 1
			elseif  isOnActiveVehicle then
				g_inputBinding.events[eventName].displayPriority = 3
			end
		end
	end

end

function Puller.registerEventListeners(vehicleType)
    EL = vehicleType.eventListeners
    table.insert(EL.onLoad, Puller)
    table.insert(EL.onUpdate, Puller)
    table.insert(EL.onDraw, Puller)
    table.insert(EL.onRegisterActionEvents, Puller)
end

function Puller:onLoad(vehicle)
	self.canBeGrabbed = Puller.canBeGrabbed;
    self.isGrabbable = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.grabbable#isGrabbable"), false);
    self.isGrabbableOnlyIfDetach = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.grabbable#isGrabbableOnlyIfDetach"), false);
    self.attachPoint = I3DUtil.indexToObject(self.components, getXMLString(self.xmlFile, "vehicle.puller#index"));
    self.attachPointCollision = I3DUtil.indexToObject(self.components, getXMLString(self.xmlFile, "vehicle.puller#rootNode"));
    self.attachRadius = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.puller#attachRadius"), 1);
    self.isAttached = false;
    self.joint = {};
    self.inRangeVehicle = nil;
	local baseName = "vehicle"
	self.pullerAttachVehicle = false
	self.sampleAttach = g_soundManager:loadSampleFromXML(self.xmlFile, baseName, "attachSound", self.baseDirectory, self.components, 1, AudioGroup.VEHICLE, self.i3dMappings, self)
end


function Puller:onUpdate()
	if self:getIsActiveForInput() then
        if self.inRangeVehicle ~= nil then
            if not self.isAttached then
                if self.pullerAttachVehicle then
                    Puller.onAttachObject(self, self.inRangeVehicle.vehicle, self.inRangeVehicle.index, nil);
                    g_soundManager:playSample(self.sampleAttach);
					self.pullerAttachVehicle = false
                end
            end
        else
            if self.isAttached then
                if self.pullerAttachVehicle then
                    Puller.onDetachObject(self);
                    g_soundManager:playSample(self.sampleAttach);
					self.pullerAttachVehicle = false
                end
            end
        end
    end
	if self:getIsActiveForInput() and not self.isAttached then
        self.inRangeVehicle = nil;
        local x, y, z = getWorldTranslation(self.attachPoint);
        for k, v in pairs(g_currentMission.vehicles) do
            local vx, vy, vz = getWorldTranslation(v.rootNode);
            if MathUtil.vector3Length(x - vx, y - vy, z - vz) <= 50 then
                for index, joint in pairs(v.spec_attacherJoints.attacherJoints) do
                    if joint.jointType == AttacherJoints.JOINTTYPE_TRAILER or joint.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW then
                        local x1, y1, z1 = getWorldTranslation(joint.jointTransform);
                        local distance = MathUtil.vector3Length(x - x1, y - y1, z - z1);
                        if distance <= self.attachRadius then
                            self.inRangeVehicle = {};
                            self.inRangeVehicle.vehicle = v;
                            self.inRangeVehicle.index = index;
                            break;
                        end
                    end
                end
                if v.attacherJoint ~= nil and self.inRangeVehicle == nil then
                    if v.attacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILER or v.attacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW then
                        local x1, y1, z1 = getWorldTranslation(v.attacherJoint.node);
                        local distance = MathUtil.vector3Length(x - x1, y - y1, z - z1);
                        if distance <= self.attachRadius then
                            self.inRangeVehicle = {};
                            self.inRangeVehicle.vehicle = v;
                            self.inRangeVehicle.index = 0;
                            break;
                        end
                    end
                end
            end
        end
    end
end
function Puller:onAttachObject(object, jointId, noEventSend)
    PullerAttachEvent.sendEvent(self, object, jointId, noEventSend);
    self.joint.object = object;
    if object.isBroken == true then
        object.isBroken = false;
    end
    if self.isServer then
        local objectAttacherJoint = nil;
        if jointId == 0 then
            objectAttacherJoint = object.attacherJoint;
        else
            objectAttacherJoint = object.spec_attacherJoints.attacherJoints[jointId];
        end
        local constr = JointConstructor:new();
        constr:setActors(self.attachPointCollision, objectAttacherJoint.rootNode);
        constr:setJointTransforms(self.attachPoint, Utils.getNoNil(objectAttacherJoint.jointTransform, objectAttacherJoint.node));
        for i = 1, 3 do
            constr:setTranslationLimit(i - 1, true, 0, 0);
            constr:setRotationLimit(i - 1, -0.35, 0.35);
            constr:setEnableCollision(false);
        end
        self.joint.index = constr:finalize();
        if not object.isControlled and object.motor ~= nil and object.wheels ~= nil then
            for k, wheel in pairs(object.wheels) do
                setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0, 0, wheel.rotationDamping);
            end
        end
        self.joint.attacherJointId = jointId;
    end
    object.forceIsActive = true;
    self.isAttached = true;
    self.inRangeVehicle = nil;
end

function Puller:onDetachObject(noEventSend)
    PullerDetachEvent.sendEvent(self, noEventSend);
    if self.isServer then
        removeJoint(self.joint.index);
        if not self.joint.object.isControlled and self.joint.object.motor ~= nil and self.joint.object.wheels ~= nil then
            for k, wheel in pairs(self.joint.object.wheels) do
                setWheelShapeProps(wheel.node, wheel.wheelShape, 0, self.joint.object.motor.brakeForce, 0, wheel.rotationDamping);
            end
        end
    end
    self.joint.object.forceIsActive = false;
    self.joint = nil;
    self.joint = {};
    self.isAttached = false;
end

function Puller:onDraw()
	if self.inRangeVehicle ~= nil then
		g_inputBinding:setActionEventTextVisibility(self.Puller.PULLER_ATTACH_VEHICLE.actionEventId, true)
		g_inputBinding:setActionEventText(self.Puller.PULLER_ATTACH_VEHICLE.actionEventId, 'Attach tow bar to vehicle')
    elseif self.inRangeVehicle == nil and self.isAttached then
		g_inputBinding:setActionEventTextVisibility(self.Puller.PULLER_ATTACH_VEHICLE.actionEventId, true)
		g_inputBinding:setActionEventText(self.Puller.PULLER_ATTACH_VEHICLE.actionEventId, 'Detach tow bar from vehicle')
    else
		g_inputBinding:setActionEventTextVisibility(self.Puller.PULLER_ATTACH_VEHICLE.actionEventId, false)
	end
end
function Puller:canBeGrabbed()
    if self.isGrabbable then
        if self.isGrabbableOnlyIfDetach then
            if not self.isAttached and self.attacherVehicle == nil then
                return true;
            end
        else
            return true
        end
    end
    return false;
end
function Player:pickUpObjectRaycastCallback(hitObjectId, x, y, z, distance)
    if distance > 0.5 and distance <= Player.MAX_PICKABLE_OBJECT_DISTANCE then
        if hitObjectId ~= g_currentMission.terrainDetailId and Player.PICKED_UP_OBJECTS[hitObjectId] ~= true then
            if getRigidBodyType(hitObjectId) == "Dynamic" then
                local object = g_currentMission:getNodeObject(hitObjectId);
                if (object ~= nil and object.dynamicMountObject == nil) or g_currentMission.nodeToVehicle[hitObjectId] == nil or (g_currentMission.nodeToVehicle[hitObjectId].canBeGrabbed ~= nil and g_currentMission.nodeToVehicle[hitObjectId]:canBeGrabbed()) then
                    self.lastFoundObject = hitObjectId;
                    self.lastFoundObjectMass = getMass(hitObjectId);
                    self.lastFoundObjectHitPoint = {x, y, z};
                    return false;
                end
            end
        end
    end
    return true;
end
function Puller:actionCallback(actionName, keyStatus, arg4, arg5, arg6)
	if keyStatus > 0 then
		if actionName == 'PULLER_ATTACH_VEHICLE' then
			self.pullerAttachVehicle = true
		end
	elseif keyStatus == 0 then
		if actionName == 'PULLER_ATTACH_VEHICLE' then
		end
	end
end
