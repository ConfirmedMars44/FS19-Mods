register = {}

function register.registerSpecializationVehicle(vehicleType, specialization, specName)
    --print("-----register specialization to vehicleType : ".. vehicleType.name)
    table.insert(vehicleType.specializationNames, specName)
    vehicleType.specializationsByName[specName] = specialization
    table.insert(vehicleType.specializations, specialization)
end

g_specializationManager.addSpecialization('puller', 'puller', 'Puller',  Utils.getFilename("Script/puller.lua", g_currentModDirectory))
    
if  g_vehicleTypeManager.vehicleTypes.puller ~= nil then
    register.registerSpecializationVehicle(g_vehicleTypeManager.vehicleTypes.puller, Puller, 'puller')
end
print("----Puller registered.")