-- @author  ClubPetey
-- Copyright (C) 2020, All Rights Reserved.
CPLog = {}
CPLog.__index = CPLog

CPLog.DEBUG = 1
CPLog.INFO = 2
CPLog.WARNING = 3
CPLog.ERROR = 4
CPLog.OFF = 1000

function CPLog:create(name, id)
  local d = {} 
  setmetatable(d, CPLog) 
  d.name = name 
  d.id = id
  d.lvl = CPLog.DEBUG
  return d
end

function CPLog:setLevel(lvl)
  self.lvl = lvl
end

function CPLog:getLevel()
  return self.lvl
end

function CPLog:debug(txt)
  self:print(CPLog.DEBUG, txt)
end

function CPLog:info(txt)
  self:print(CPLog.INFO, txt)
end

function CPLog:warn(txt)
  self:print(CPLog.WARNING, txt)
end

function CPLog:error(txt)
  self:print(CPLog.ERROR, txt)
end

function CPLog:dump(tbl, ind) 
  self:debug(string.rep("-", ind) .. " (" .. type(tbl) .. ")")

  if (type(tbl) == "table") then
    for k, v in pairs(tbl) do
      self:debug(string.rep("-", ind+1) .. " " ..k .. " (" .. type(v) .. ")")
    end  
  end
end

function CPLog:print(lvl, txt)  
  if lvl < self.lvl then
    return
  end
  level = "ERROR"
  if lvl == CPLog.WARNING then
    level = "WARN"
  elseif lvl == CPLog.INFO then
    level = "INFO"
  elseif lvl == CPLog.DEBUG then
    level = "DEBUG"
  end

  local text
  if type(txt) == "function" then
    text = txt()
  else
    text = txt
  end

  print("[" .. level .. "] " .. self.name .. ": " .. text)
end