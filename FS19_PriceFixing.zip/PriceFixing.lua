-- @author        ClubPetey
-- Copyright (C) 2020, All Rights Reserved.

PriceFixing = {};
PriceFixing.dir = getUserProfileAppPath() .. "mods/";
PriceFixing.version = "1.1.0.0";
PriceFixing.versionDate = "10.12.2020";
PriceFixing.currentVersionId = 1100; 
PriceFixing.configFileName = "PriceFixing.xml";
PriceFixing.initialized = false;
PriceFixing.fillType = {};
PriceFixing.globalMapEdits = {};

function init() 
  PriceFixing.log = CPLog:create("PriceFixing");
  PriceFixing.log:setLevel(CPLog.INFO);
  
  addConsoleCommand("priceList", "Send a price list of store items and fill-types to log.txt", "priceList", PriceFixing);
  addModEventListener(PriceFixing);

  FSBaseMission.loadMapFinished = Utils.appendedFunction(FSBaseMission.loadMapFinished, mapLoaded)
end

function mapLoaded(mission, node, data)
  PriceFixing:onMapLoaded(mission, node); 
end

-- In theory at this point the economy hasn't been activated, but the types have been loaded.
-- Changes should be done here. But I grab the original prices for the priceList function
function PriceFixing:onMapLoaded(mission, root)
  self.log:debug("Map loaded");
  i = 0;  
  while true do
    local keySub = string.format("PriceFixing.change_filltype(%d)", i);  
    if not hasXMLProperty(self.xmlFile, keySub) then
      break;
    end;

    local price = Utils.getNoNil(getXMLFloat(self.xmlFile, keySub.."#price"), -1.0);
    local name = Utils.getNoNil(getXMLString(self.xmlFile, keySub.."#id"), "");   

    if name ~= "" and price ~= -1 then
      ft = g_fillTypeManager:getFillTypeByName(name:upper());
      if ft ~= nil then
        self.log:debug(string.format("FillType change: [%s] %f -> %f", name, ft.pricePerLiter, price));
        ft.pricePerLiter = price;
      end
    end

    i = i + 1;
  end

  types = g_fillTypeManager:getFillTypes()
  for _, ft in pairs(types) do    
    ftdata = {}
    ftdata.pricePerLiter = ft.pricePerLiter;
    ftdata.name = ft.name;
    self.fillType[ft.name] = ftdata;
  end

  delete(self.xmlFile);
  self:cleanMap(root);
end

function PriceFixing:cleanMap(root) 
  if (table.getn(self.globalMapEdits) > 0) then
    i = 0;
    for _, path in ipairs(self.globalMapEdits) do
      target = I3DUtil.indexToObject(root, path);
      if (target ~= nil) then
        i = i + 1;
			  unlink(target); 
      end
    end
  end  
  self.log:info(string.format("Removed %d/%d map nodes", i, table.getn(self.globalMapEdits)));
end

function PriceFixing:expandItemTag(tag) 
  tag = tag:lower()
  if (tag:sub(1, 1) == "~") then
    return PriceFixing.dir .. tag:sub(3)
  else 
    return tag
  end
end

function PriceFixing:createDefaultConfig(fileName)
  createFolder(getUserProfileAppPath() .. "modsSettings/")
  local xml = createXMLFile("PriceFixing", fileName, "PriceFixing");
  setXMLString(xml, "PriceFixing.change#file", "~/example_mod/mod_item.xml")
  setXMLInt(xml, "PriceFixing.change#price", 1000000)
  saveXMLFile(xml)
  delete(xml)
end

function PriceFixing:priceList() 
  local lvl = self.log:getLevel();

  self.log:debug("--- START PRICE LIST ---");
  local items = g_storeManager:getItems();

  for _, item in pairs(items) do
    if (item.canBeSold and item.showInStore) then
      self.log:debug(item.xmlFilename .. " (" .. item.name .. ") = " .. item.price .. " / " .. item.dailyUpkeep);
    else 
      self.log:debug(item.xmlFilename .. " (**" .. item.name .. "**) = " .. item.price);
    end
  end
  self.log:debug("--- END PRICE LIST ---");
  self.log:debug("--- START TYPE LIST ---");
  for _, v in pairs(self.fillType) do    
    self.log:debug(string.format("%s = %f", v.name, v.pricePerLiter));
  end
  self.log:debug("--- END TYPE LIST ---");

  self.log:setLevel(lvl);
end

function PriceFixing:loadMap(name)
  self.log:debug("Map is: " .. name);
  local configFile = getUserProfileAppPath() .. "modsSettings/" .. PriceFixing.configFileName;

  self.log:debug("Mod directory is: " .. PriceFixing.dir);
  self.log:info("Looking for changes in: " .. configFile);
  
  if not fileExists(configFile) then
    self.log:info("No change file found -- creating a new one");
    self:createDefaultConfig(configFile)
    return
  end

  xmlFile = loadXMLFile("PriceFixing", configFile);
  self.xmlFile = xmlFile

  Player.MAX_PICKABLE_OBJECT_MASS = 6;

  i = 0;
  skip = 0;

  while true do
    local keySub = string.format("PriceFixing.change(%d)", i);
    
    if not hasXMLProperty(xmlFile, keySub) then
      break;
    end;

    local itemTag = getXMLString(xmlFile, keySub.."#file");
    

    local price = Utils.getNoNil(getXMLInt(xmlFile, keySub.."#price"), -1);
    if (price == -1) then 
      price = Utils.getNoNil(getXMLInt(xmlFile, keySub..".price"), -1);
    end

    local upkeep = Utils.getNoNil(getXMLInt(xmlFile, keySub.."#upkeep"), -1);
    if (upkeep == -1) then 
      upkeep = Utils.getNoNil(getXMLInt(xmlFile, keySub..".upkeep"), -1);
    end

    local income = Utils.getNoNil(getXMLString(xmlFile, keySub.."#income"), "");
    if (income == "") then 
      income = Utils.getNoNil(getXMLString(xmlFile, keySub..".income"), "");
    end

    local capacity = Utils.getNoNil(getXMLString(xmlFile, keySub.."#capacity"), "");
    if (capacity == "") then 
      capacity = Utils.getNoNil(getXMLString(xmlFile, keySub..".capacity"), "");
    end

    local hide = Utils.getNoNil(getXMLBool(xmlFile, keySub.."#hide"), false);
    local name = Utils.getNoNil(getXMLString(xmlFile, keySub..".name"), "");
    
    if itemTag == nil then 
      self.log:warn(string.format("Skipping change %d: No itemTag", i));
      skip = skip + 1;
    else
      itemTag = self:expandItemTag(itemTag);
      local item = g_storeManager:getItemByXMLFilename(itemTag);

      if item == nil then
        self.log:warn(string.format("Skipping change %d: Item not found", i));
        skip = skip + 1;
      else
        if (hide) then
          item.showInStore = false
          self.log:debug(string.format("Hid item %d: %s", i, itemTag));
        else
          if (price ~= -1) then
            self.log:debug(string.format("Change price %d: %s -> %s", i, item.price, price));
            item.price = price;
          end

          if (name ~= "") then
            self.log:debug(string.format("Change name %d: %s -> %s", i, item.name, name));
            item.name = name;
          end

          if (upkeep ~= -1) then
            self.log:debug(string.format("Change upkeep %d: %d -> %d", i, item.dailyUpkeep , upkeep));
            item.dailyUpkeep  = upkeep;
          end

          if (income ~= "" and item.specs.incomePerHour ~= nil) then
            incomeList = StringUtil.splitString(",", income)
            for j, _ in ipairs(incomeList) do              
              self.log:debug(string.format("Change income %d: %d -> %d", j, item.specs.incomePerHour[j] , tonumber(incomeList[j])));
              item.specs.incomePerHour[j] = tonumber(incomeList[j]);
            end
          end

          if (capacity ~= "" and (item.specs.capacity ~= nil or item.specs.siloVolume ~= nil)) then
            capList = StringUtil.splitString(",", capacity)  
            if item.specs.siloVolume ~= nil then
                self.log:debug(string.format("Change silo capacity: %d -> %d", item.specs.siloVolume, tonumber(capList[1])));
                item.specs.siloVolume = tonumber(capList[1]);
            else
              for j, _ in ipairs(capList) do              
                self.log:debug(string.format("Change capacity %d: %d -> %d", j, item.specs.capacity[j] , tonumber(capList[j])));
                item.specs.capacity[j] = tonumber(capList[j]);
              end
            end

          end

        end
      end      
    end
    i = i + 1;
  end;  

  self.log:info(string.format("Made %d item changes", i - skip));

  i = 0;

  local configChanges = {}  

  while true do
    local keySub = string.format("PriceFixing.change_config(%d)", i);  
    if not hasXMLProperty(xmlFile, keySub) then
      break;
    end;

    local change = {};
    change.price = Utils.getNoNil(getXMLInt(xmlFile, keySub.."#price"), -1);    
    local name = Utils.getNoNil(getXMLString(xmlFile, keySub.."#id"), "");    
    if name ~= "" then
      local index = string.find(name, "-[^-]*$");
      change.id = name:sub(1, index-1);
      change.idx = tonumber(name:sub(index+1));

      self.log:debug(string.format("Global Price change: %s[%d] -> %d", change.id, change.idx, change.price));
      table.insert(configChanges, change)
    end
    i = i + 1;
  end

  if (table.getn(configChanges) > 0) then
    i = 0;
    local items = g_storeManager:getItems();
    for _, item in pairs(items) do
      for _, c in ipairs(configChanges) do
        if (item.configurations ~= nil and item.configurations[c.id] ~= nil and item.configurations[c.id][c.idx] ~= nil) then
          item.configurations[c.id][c.idx].price = c.price;
          i = i + 1;
        end      
      end
    end
    self.log:info(string.format("Made %d global config changes", i));
  end

  while true do
    local keySub = string.format("PriceFixing.delete(%d)", i);
    if not hasXMLProperty(xmlFile, keySub) then
      break;
    end;

    local map = Utils.getNoNil(getXMLString(xmlFile, keySub.."#map"), "");    
    if (name == map) then
      local node = Utils.getNoNil(getXMLString(xmlFile, keySub.."#node"), "");    
      if node ~= "" then
        self.log:debug(string.format("Delete node %d: %s", i, node));
        table.insert(self.globalMapEdits, node)
      end
    end
    i = i + 1;
  end

  -- this will be done in onMapLoaded()
  -- delete(xmlFile)
end

function PriceFixing:deleteMap()
end

init()

